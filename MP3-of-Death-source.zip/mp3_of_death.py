#!/usr/bin/env python3
"""
MP3 of Death -- CD Audio Ripper
Death's Head Software

Dependency: fre:ac portable  https://www.freac.org/downloads
  Extract ALL files from the portable zip into this script's folder
  (freaccmd.exe + freac.dll + smooth.dll + everything else).

pip dependency:  mutagen  (pip install mutagen)  -- ID3 tag injection
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QAbstractItemView, QApplication, QComboBox, QFileDialog,
    QFrame, QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QProgressBar,
    QPushButton, QSplashScreen, QStatusBar, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
)

APP_NAME       = "MP3 of Death"
ORG_NAME       = "Death's Head Software"
VERSION        = "1.0.0"
APP_ID         = "DeathsHeadSoftware.MP3ofDeath.1"   # Windows AppUserModelID
DEFAULT_DEVICE = "D:"

MP3_BITRATES   = ["32", "64", "96", "128", "192", "256", "320"]
DEFAULT_BR_IDX = 6

BG   = "#0d0d0d"
BG2  = "#070707"
ACC  = "#cc0000"
ACC2 = "#ff3333"
FG   = "#dddddd"
DIM  = "#666666"
BORD = "#252525"
ALT  = "#101010"

QSS = f"""
QWidget            {{ background:{BG}; color:{FG}; font-family:'Courier New',monospace; font-size:13px; }}
QMainWindow        {{ background:{BG}; }}
QGroupBox          {{ border:1px solid {BORD}; margin-top:10px; color:{DIM}; font-size:12px; }}
QGroupBox::title   {{ subcontrol-origin:margin; left:8px; padding:0 4px; }}
QLabel             {{ color:{FG}; }}
QLineEdit          {{ background:#141414; color:{FG}; border:1px solid {BORD}; padding:4px 8px; }}
QLineEdit:focus    {{ border-color:#444; }}
QLineEdit:disabled {{ color:#3a3a3a; background:#0e0e0e; }}
QComboBox          {{ background:#141414; color:{FG}; border:1px solid {BORD}; padding:4px 8px; }}
QComboBox::drop-down            {{ border:none; width:20px; }}
QComboBox QAbstractItemView     {{ background:#141414; color:{FG}; selection-background-color:{ACC}; border:1px solid {BORD}; }}
QPushButton                     {{ background:#181818; color:{FG}; border:1px solid {BORD}; padding:6px 14px; }}
QPushButton:hover               {{ background:#222; border-color:#444; }}
QPushButton:disabled            {{ color:#383838; border-color:#1c1c1c; }}
QPushButton#ripBtn              {{ background:{ACC}; color:#fff; border:1px solid #880000; font-weight:bold; font-size:14px; padding:8px 32px; }}
QPushButton#ripBtn:hover        {{ background:{ACC2}; }}
QPushButton#ripBtn:disabled     {{ background:#3a0000; color:#555; border-color:#200000; }}
QPushButton#cancelBtn           {{ color:#cc4444; border:1px solid #3a1515; padding:8px 28px; }}
QPushButton#cancelBtn:hover     {{ background:#1c0b0b; border-color:#775555; }}
QPushButton#cancelBtn:disabled  {{ color:#333; border-color:#191919; }}
QTableWidget                    {{ background:{BG2}; color:{FG}; gridline-color:{BORD}; border:1px solid {BORD}; alternate-background-color:{ALT}; selection-background-color:#350000; selection-color:{FG}; }}
QTableWidget::item              {{ padding:4px 6px; }}
QHeaderView::section            {{ background:#111; color:{DIM}; border:1px solid {BORD}; padding:5px 8px; font-size:11px; letter-spacing:1px; }}
QProgressBar                    {{ background:#0a0a0a; border:1px solid {BORD}; text-align:center; color:#ccc; font-size:11px; }}
QProgressBar::chunk             {{ background:{ACC}; }}
QTextEdit                       {{ background:{BG2}; color:#888; border:1px solid {BORD}; font-size:12px; }}
QStatusBar                      {{ background:#080808; color:{DIM}; border-top:1px solid {BORD}; font-size:11px; }}
QScrollBar:vertical             {{ background:{BG}; width:7px; border:none; }}
QScrollBar::handle:vertical     {{ background:#2e2e2e; min-height:20px; border-radius:3px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical   {{ height:0; border:none; }}
QScrollBar:horizontal           {{ background:{BG}; height:7px; border:none; }}
QScrollBar::handle:horizontal   {{ background:#2e2e2e; min-width:20px; border-radius:3px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width:0; border:none; }}
"""


# =============================================================================
# Icon + AppUserModelID
# =============================================================================

def _find_icon() -> Path | None:
    """Locate icon.ico -- checks _MEIPASS first for bundled builds."""
    if hasattr(sys, "_MEIPASS"):
        p = Path(sys._MEIPASS) / "icon.ico"
        if p.exists():
            return p
    p = Path(__file__).resolve().parent / "icon.ico"
    return p if p.exists() else None


def _set_app_user_model_id() -> None:
    """
    Tell Windows which AppUserModelID this process belongs to.
    Without this, the taskbar groups the app under a generic Python/PyInstaller
    identity and uses the wrong icon.  Must be called before any window is shown.
    """
    if sys.platform == "win32":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
        except Exception:
            pass


# =============================================================================
# Tool Resolution
# =============================================================================

def _find_freaccmd() -> Path | None:
    if hasattr(sys, "_MEIPASS"):
        mp = Path(sys._MEIPASS)
        for p in [mp / "bin" / "freac" / "freaccmd.exe",
                  mp / "bin" / "freaccmd.exe",
                  mp / "freaccmd.exe"]:
            if p.exists():
                return p.resolve()
        for p in mp.rglob("freaccmd.exe"):
            return p.resolve()

    base = Path(__file__).resolve().parent
    for p in [base / "freaccmd.exe",
              base / "freaccmd",
              base / "bin" / "freac" / "freaccmd.exe",
              base / "bin" / "freaccmd.exe",
              Path(r"C:\Program Files\fre:ac\freaccmd.exe"),
              Path(r"C:\Program Files (x86)\fre:ac\freaccmd.exe")]:
        if p.exists():
            return p.resolve()

    found = shutil.which("freaccmd")
    return Path(found).resolve() if found else None


def _check_dlls(freaccmd: Path) -> list[str]:
    d = freaccmd.parent
    return [dll for dll in ("freac.dll", "smooth.dll") if not (d / dll).exists()]


def _make_env(freac_dir: Path) -> dict:
    env = os.environ.copy()
    env["PATH"] = str(freac_dir) + os.pathsep + env.get("PATH", "")
    return env


# =============================================================================
# CD Drive Detection
# =============================================================================

_GENERIC_READ         = 0x80000000
_FILE_SHARE_READ      = 0x00000001
_FILE_SHARE_WRITE     = 0x00000002
_FILE_SHARE_RW        = _FILE_SHARE_READ | _FILE_SHARE_WRITE
_OPEN_EXISTING        = 3
_IOCTL_CDROM_READ_TOC = 0x00024000
_DRIVE_CDROM          = 5
_INVALID_HANDLE       = ctypes.c_void_p(-1).value

_TOC_ERRORS: dict[int, str] = {
    2:  "Drive not found. Check the drive letter.",
    5:  "Access denied. Try running as Administrator.",
    21: "Drive not ready -- no disc inserted, or wrong drive letter.",
    31: "Device error. Try a different disc or drive.",
    87: "Invalid parameter passed to device.",
}


class _TrackData(ctypes.Structure):
    _fields_ = [
        ("Reserved",    ctypes.c_ubyte),
        ("Ctrl_Adr",    ctypes.c_ubyte),
        ("TrackNumber", ctypes.c_ubyte),
        ("Reserved1",   ctypes.c_ubyte),
        ("Address",     ctypes.c_ubyte * 4),
    ]


class _CDROM_TOC(ctypes.Structure):
    _fields_ = [
        ("Length",     ctypes.c_ubyte * 2),
        ("FirstTrack", ctypes.c_ubyte),
        ("LastTrack",  ctypes.c_ubyte),
        ("TrackData",  _TrackData * 100),
    ]


def _msf_to_frames(m: int, s: int, f: int) -> int:
    return m * 75 * 60 + s * 75 + f


def get_cd_drives() -> list[str]:
    if sys.platform != "win32":
        return []
    drives = []
    bitmask = ctypes.windll.kernel32.GetLogicalDrives()
    for i in range(26):
        if bitmask & (1 << i):
            letter = chr(ord("A") + i) + ":"
            if ctypes.windll.kernel32.GetDriveTypeW(letter + "\\") == _DRIVE_CDROM:
                drives.append(letter)
    return drives


def read_cd_toc(drive_letter: str) -> tuple[list[tuple[int, str]] | None, str]:
    if sys.platform != "win32":
        return None, "CD TOC reading only supported on Windows."
    drive  = drive_letter.strip(":\\/ ").upper()
    k32    = ctypes.windll.kernel32
    handle = k32.CreateFileW(
        f"\\\\.\\{drive}:", _GENERIC_READ, _FILE_SHARE_RW,
        None, _OPEN_EXISTING, 0, None,
    )
    if handle == _INVALID_HANDLE:
        err = k32.GetLastError()
        return None, _TOC_ERRORS.get(err, f"Windows error {err}.")
    try:
        toc = _CDROM_TOC()
        br  = ctypes.c_ulong(0)
        ok  = k32.DeviceIoControl(
            handle, _IOCTL_CDROM_READ_TOC, None, 0,
            ctypes.byref(toc), ctypes.sizeof(toc), ctypes.byref(br), None,
        )
        if not ok:
            err = k32.GetLastError()
            return None, _TOC_ERRORS.get(err, f"Windows error {err}.")
        tracks: list[tuple[int, str]] = []
        for i in range(toc.FirstTrack, toc.LastTrack + 1):
            ci = i - toc.FirstTrack
            a0 = toc.TrackData[ci].Address
            a1 = toc.TrackData[ci + 1].Address
            dur_s = (_msf_to_frames(a1[1], a1[2], a1[3]) -
                     _msf_to_frames(a0[1], a0[2], a0[3])) // 75
            m, s = divmod(dur_s, 60)
            tracks.append((i, f"{m}:{s:02d}"))
        return tracks, ""
    finally:
        k32.CloseHandle(handle)


# =============================================================================
# ID3 Tag Injection
# =============================================================================

def _write_id3(path: str, title: str, artist: str, album: str, track_num: int) -> None:
    try:
        from mutagen.id3 import ID3, ID3NoHeaderError, TIT2, TPE1, TALB, TRCK
        try:
            tags = ID3(path)
        except ID3NoHeaderError:
            tags = ID3()
        tags["TIT2"] = TIT2(encoding=3, text=title)
        tags["TRCK"] = TRCK(encoding=3, text=str(track_num))
        if artist:
            tags["TPE1"] = TPE1(encoding=3, text=artist)
        if album:
            tags["TALB"] = TALB(encoding=3, text=album)
        tags.save(path, v2_version=3)
    except Exception:
        pass


# =============================================================================
# Workers
# =============================================================================

class CDDetectWorker(QThread):
    detected = pyqtSignal(int, list)
    error    = pyqtSignal(str)

    def __init__(self, device: str):
        super().__init__()
        self.device = device

    def run(self):
        tracks, err = read_cd_toc(self.device)
        if tracks is None:
            self.error.emit(err)
        elif not tracks:
            self.error.emit("Disc has no audio tracks.")
        else:
            self.detected.emit(len(tracks), tracks)


class RipWorker(QThread):
    log          = pyqtSignal(str)
    progress     = pyqtSignal(int, int)
    track_active = pyqtSignal(int)
    track_done   = pyqtSignal(int)
    finished     = pyqtSignal(bool, str)

    def __init__(self, tracks, output_dir, bitrate, artist, album, device):
        super().__init__()
        self.tracks     = tracks
        self.output_dir = output_dir
        self.bitrate    = bitrate
        self.artist     = artist.strip()
        self.album      = album.strip()
        self.device     = device
        self._cancel    = False

    def cancel(self):
        self._cancel = True

    def run(self):
        freaccmd = _find_freaccmd()
        if not freaccmd:
            self.finished.emit(False, "freaccmd.exe not found.")
            return

        missing = _check_dlls(freaccmd)
        if missing:
            self.finished.emit(False,
                f"Missing DLLs: {', '.join(missing)}\n"
                "Extract the ENTIRE fre:ac portable zip alongside freaccmd.exe.")
            return

        freac_dir = freaccmd.parent
        no_win    = {"creationflags": subprocess.CREATE_NO_WINDOW} if sys.platform == "win32" else {}
        env       = _make_env(freac_dir)
        total     = len(self.tracks)
        out       = Path(self.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        done      = 0

        for idx, (track_num, name) in enumerate(self.tracks):
            if self._cancel:
                self.finished.emit(False, f"Cancelled -- {done}/{total} tracks saved.")
                return

            self.track_active.emit(idx)
            safe     = self._safe(name) or f"Track {track_num:02d}"
            out_file = out / f"{safe}.mp3"

            self.log.emit(f"[{idx+1}/{total}]  Track {track_num:02d}  ->  {safe}")
            self.progress.emit(idx, total)

            snap_out = set(out.glob("*.mp3"))
            snap_cwd = set(freac_dir.glob("*.mp3"))

            cmd = [
                str(freaccmd),
                "-e", "LAME",
                "-cd", self.device,
                "-t", str(track_num),
                "-d", str(out),
                "--quiet",
                "--", "-b", self.bitrate,
            ]

            try:
                proc = subprocess.run(
                    cmd,
                    capture_output=True, text=True,
                    timeout=600,
                    cwd=str(freac_dir),
                    env=env,
                    **no_win,
                )
                if proc.returncode != 0:
                    snippet = (proc.stderr + proc.stdout).strip()[:300]
                    self.log.emit(f"  x freaccmd (code {proc.returncode}): {snippet}")
                    continue
            except subprocess.TimeoutExpired:
                self.log.emit(f"  x Timeout on track {track_num}")
                continue
            except Exception as e:
                self.log.emit(f"  x {e}")
                continue

            # Poll up to 10 s for the file to appear
            created: Path | None = None
            deadline = time.time() + 10
            while time.time() < deadline:
                new_out = set(out.glob("*.mp3"))       - snap_out
                new_cwd = set(freac_dir.glob("*.mp3")) - snap_cwd
                if new_out:
                    created = next(iter(new_out)); break
                if new_cwd:
                    created = next(iter(new_cwd))
                    self.log.emit(f"  ~ freaccmd wrote to its own dir: {created.name}")
                    break
                time.sleep(0.25)

            if created is None:
                self.log.emit("  x No .mp3 appeared after rip.")
                continue

            if created.resolve() != out_file.resolve():
                try:
                    if out_file.exists():
                        out_file.unlink()
                    shutil.move(str(created), str(out_file))
                except Exception as e:
                    self.log.emit(f"  ~ Rename failed ({e}), keeping: {created.name}")
                    out_file = created

            self.log.emit(f"  + MP3 -> {out_file.name}")
            _write_id3(str(out_file), name, self.artist, self.album, track_num)
            parts = [x for x in (self.artist, self.album) if x]
            self.log.emit("  + ID3 tagged" + (f"  [{', '.join(parts)}]" if parts else ""))

            self.track_done.emit(idx)
            done += 1

        self.progress.emit(total, total)
        self.finished.emit(True, f"Done -- {done}/{total} track(s) saved to {self.output_dir}")

    @staticmethod
    def _safe(name: str) -> str:
        return re.sub(r'[\\/:*?"<>|]', "", name).strip()


# =============================================================================
# Dynamic Song-Name Table
# =============================================================================

class SongTable(QTableWidget):
    _GREY  = QColor(80,  80,  80)
    _GREEN = QColor(60, 180, 60)
    _RED   = QColor(200, 60,  60)

    def __init__(self, parent=None):
        super().__init__(1, 2, parent)
        self.setHorizontalHeaderLabels(["#", "Track Name"])
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setEditTriggers(
            QAbstractItemView.EditTrigger.DoubleClicked |
            QAbstractItemView.EditTrigger.SelectedClicked |
            QAbstractItemView.EditTrigger.AnyKeyPressed
        )
        hdr = self.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.setColumnWidth(0, 38)
        self._blocked = False
        self._stamp_num(0)
        self.itemChanged.connect(self._on_change)

    def _stamp_num(self, row: int):
        item = QTableWidgetItem(str(row + 1))
        item.setFlags(Qt.ItemFlag.ItemIsEnabled)
        item.setForeground(QBrush(self._GREY))
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setItem(row, 0, item)

    def _on_change(self, item: QTableWidgetItem):
        if self._blocked or item.column() != 1:
            return
        if item.row() == self.rowCount() - 1 and item.text().strip():
            self._blocked = True
            r = self.rowCount()
            self.insertRow(r)
            self._stamp_num(r)
            self._blocked = False

    def load_track_count(self, count: int):
        self._blocked = True
        self.setRowCount(0)
        for i in range(count + 1):
            self.insertRow(i)
            self._stamp_num(i)
            if i < count:
                self.setItem(i, 1, QTableWidgetItem(""))
        self._blocked = False

    def get_named_tracks(self) -> list[tuple[int, str]]:
        result = []
        for row in range(self.rowCount()):
            item = self.item(row, 1)
            name = item.text().strip() if item else ""
            if name:
                result.append((row + 1, name))
        return result

    def mark_active(self, row: int):
        self._set_row_color(row, self._RED)

    def mark_done(self, row: int):
        self._set_row_color(row, self._GREEN)

    def _set_row_color(self, row: int, color: QColor):
        for col in range(self.columnCount()):
            it = self.item(row, col)
            if it:
                it.setForeground(QBrush(color))


# =============================================================================
# Splash Screen
# =============================================================================

def create_splash(app_icon: QIcon | None) -> QSplashScreen | None:
    try:
        splash_path = Path(__file__).resolve().parent / "splash.png"
        if not splash_path.exists() and hasattr(sys, "_MEIPASS"):
            splash_path = Path(sys._MEIPASS) / "splash.png"
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(13, 13, 13))
            pixmap = pixmap.scaled(800, 600,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier New", 36, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(28); r.setBottom(88)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter, APP_NAME)
            painter.setFont(QFont("Courier New", 13, QFont.Weight.Bold))
            fr = pixmap.rect()
            fr.setTop(pixmap.height() - 55); fr.setBottom(pixmap.height() - 8)
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter, ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(13, 13, 13))
            painter = QPainter(pixmap)
            painter.setPen(QColor(204, 0, 0))
            painter.setFont(QFont("Courier New", 36, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(28); r.setBottom(88)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter, APP_NAME)
            painter.setPen(QColor(220, 220, 220))
            painter.setFont(QFont("Courier New", 14))
            skull = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y = 230
            for line in skull:
                painter.drawText(210, y, line)
                y += 26
            painter.setFont(QFont("Courier New", 13, QFont.Weight.Bold))
            fr = pixmap.rect()
            fr.setTop(pixmap.height() - 55); fr.setBottom(pixmap.height() - 8)
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter, ORG_NAME)
            painter.end()

        splash = QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
        if app_icon:
            splash.setWindowIcon(app_icon)
        return splash
    except Exception as e:
        print(f"Splash error: {e}")
        return None


# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self, app_icon: QIcon | None):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  --  {ORG_NAME}")
        self.resize(920, 680)
        if app_icon:
            self.setWindowIcon(app_icon)
        self._worker: RipWorker | None      = None
        self._detect: CDDetectWorker | None = None
        self._build_ui()
        self._check_tools()
        self._auto_detect_drive()
        self._sync_controls()

    def _build_ui(self):
        root_w = QWidget()
        self.setCentralWidget(root_w)
        root = QVBoxLayout(root_w)
        root.setContentsMargins(12, 10, 12, 8)
        root.setSpacing(8)

        hdr = QHBoxLayout()
        lbl_title = QLabel(APP_NAME)
        lbl_title.setFont(QFont("Courier New", 22, QFont.Weight.Bold))
        lbl_title.setStyleSheet(f"color:{ACC};")
        lbl_org = QLabel(ORG_NAME)
        lbl_org.setFont(QFont("Courier New", 11))
        lbl_org.setStyleSheet(f"color:{DIM};")
        lbl_org.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        hdr.addWidget(lbl_title)
        hdr.addStretch()
        hdr.addWidget(lbl_org)
        root.addLayout(hdr)

        det_row = QHBoxLayout()
        self.lbl_cd = QLabel("No disc detected.")
        self.lbl_cd.setStyleSheet(f"color:{DIM};")
        self.btn_detect = QPushButton("Detect CD")
        self.btn_detect.setFixedWidth(130)
        self.btn_detect.clicked.connect(self._detect_cd)
        det_row.addWidget(self.lbl_cd, 1)
        det_row.addWidget(self.btn_detect)
        root.addLayout(det_row)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color:{BORD};")
        root.addWidget(sep)

        body = QHBoxLayout()
        body.setSpacing(10)

        tbl_grp = QGroupBox("Track Names")
        tbl_lay = QVBoxLayout(tbl_grp)
        tbl_lay.setContentsMargins(6, 14, 6, 6)
        self.song_table = SongTable()
        tbl_lay.addWidget(self.song_table)
        body.addWidget(tbl_grp, 3)

        scol = QVBoxLayout()
        scol.setSpacing(8)

        out_grp = QGroupBox("Output Directory")
        out_lay = QVBoxLayout(out_grp)
        out_lay.setContentsMargins(6, 14, 6, 6)
        dir_row = QHBoxLayout()
        self.out_edit = QLineEdit(str(Path.home() / "Music"))
        self.btn_browse = QPushButton("...")
        self.btn_browse.setFixedWidth(34)
        self.btn_browse.clicked.connect(self._browse)
        dir_row.addWidget(self.out_edit)
        dir_row.addWidget(self.btn_browse)
        out_lay.addLayout(dir_row)
        scol.addWidget(out_grp)

        br_grp = QGroupBox("Bitrate")
        br_lay = QVBoxLayout(br_grp)
        br_lay.setContentsMargins(6, 14, 6, 6)
        self.br_combo = QComboBox()
        for b in MP3_BITRATES:
            self.br_combo.addItem(f"{b} kbps", b)
        self.br_combo.setCurrentIndex(DEFAULT_BR_IDX)
        br_lay.addWidget(self.br_combo)
        scol.addWidget(br_grp)

        meta_grp = QGroupBox("MP3 Metadata  (ID3 tags)")
        meta_lay = QVBoxLayout(meta_grp)
        meta_lay.setContentsMargins(6, 14, 6, 8)
        meta_lay.setSpacing(6)
        self.artist_edit = QLineEdit()
        self.artist_edit.setPlaceholderText("Artist")
        self.album_edit  = QLineEdit()
        self.album_edit.setPlaceholderText("Album")
        for lbl_text, widget in [("Artist:", self.artist_edit), ("Album:", self.album_edit)]:
            row_lay = QHBoxLayout()
            lbl = QLabel(lbl_text)
            lbl.setFixedWidth(46)
            lbl.setStyleSheet(f"color:{DIM};")
            row_lay.addWidget(lbl)
            row_lay.addWidget(widget)
            meta_lay.addLayout(row_lay)
        note = QLabel("Title and track number are set automatically from the table.")
        note.setStyleSheet(f"color:{DIM}; font-size:11px;")
        note.setWordWrap(True)
        meta_lay.addWidget(note)
        scol.addWidget(meta_grp)

        dev_grp = QGroupBox("CD Drive")
        dev_lay = QVBoxLayout(dev_grp)
        dev_lay.setContentsMargins(6, 14, 6, 6)
        self.dev_edit = QLineEdit(DEFAULT_DEVICE)
        dev_lay.addWidget(self.dev_edit)
        scol.addWidget(dev_grp)

        scol.addStretch()
        body.addLayout(scol, 2)
        root.addLayout(body, 4)

        log_grp = QGroupBox("Activity Log")
        log_lay = QVBoxLayout(log_grp)
        log_lay.setContentsMargins(6, 14, 6, 8)
        log_lay.setSpacing(6)
        self.log_edit = QTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setFixedHeight(110)
        log_lay.addWidget(self.log_edit)
        self.prog_bar = QProgressBar()
        self.prog_bar.setRange(0, 100)
        self.prog_bar.setValue(0)
        self.prog_bar.setFixedHeight(18)
        log_lay.addWidget(self.prog_bar)
        root.addWidget(log_grp)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel_rip)
        self.btn_rip = QPushButton("RIP")
        self.btn_rip.setObjectName("ripBtn")
        self.btn_rip.clicked.connect(self._start_rip)
        btn_row.addWidget(self.btn_cancel)
        btn_row.addSpacing(8)
        btn_row.addWidget(self.btn_rip)
        root.addLayout(btn_row)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage(f"{APP_NAME} {VERSION}  |  Ready")

    def _auto_detect_drive(self):
        drives = get_cd_drives()
        if drives:
            self.dev_edit.setText(drives[0])
            if len(drives) == 1:
                self._log(f"+ CD drive: {drives[0]}")
            else:
                self._log(f"+ CD drives found: {', '.join(drives)}  (using {drives[0]})")
        else:
            self._log("  No CD drives detected.")

    def _check_tools(self):
        freaccmd = _find_freaccmd()
        if not freaccmd:
            self._log("  freaccmd.exe not found.")
            self._log("  https://www.freac.org/downloads -- extract ALL files here.")
            return
        missing = _check_dlls(freaccmd)
        if missing:
            self._log(f"  freaccmd: {freaccmd}")
            self._log(f"  Missing DLLs: {', '.join(missing)}")
        else:
            self._log(f"+ freaccmd: {freaccmd}")
        try:
            import mutagen  # noqa: F401
            self._log("+ mutagen: ID3 tagging available")
        except ImportError:
            self._log("  mutagen not installed -- pip install mutagen")

    def _sync_controls(self):
        ripping = self._worker is not None and self._worker.isRunning()
        self.btn_rip.setEnabled(not ripping)
        self.btn_cancel.setEnabled(ripping)
        self.btn_detect.setEnabled(not ripping)
        self.br_combo.setEnabled(not ripping)
        self.out_edit.setEnabled(not ripping)
        self.btn_browse.setEnabled(not ripping)
        self.dev_edit.setEnabled(not ripping)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(
            self, "Select Output Directory", self.out_edit.text())
        if d:
            self.out_edit.setText(d)

    def _log(self, msg: str):
        self.log_edit.append(msg)
        self.log_edit.verticalScrollBar().setValue(
            self.log_edit.verticalScrollBar().maximum())

    def _detect_cd(self):
        self.lbl_cd.setText("Detecting...")
        self.lbl_cd.setStyleSheet(f"color:{DIM};")
        self.btn_detect.setEnabled(False)
        self._log("Reading disc TOC...")
        self._detect = CDDetectWorker(self.dev_edit.text() or DEFAULT_DEVICE)
        self._detect.detected.connect(self._on_cd_detected)
        self._detect.error.connect(self._on_cd_error)
        self._detect.start()

    def _on_cd_detected(self, count: int, tracks: list):
        self.lbl_cd.setText(f"+  {count} track(s) detected")
        self.lbl_cd.setStyleSheet("color:#44cc44;")
        self.song_table.load_track_count(count)
        self._log(f"Disc detected -- {count} tracks:")
        for num, dur in tracks:
            self._log(f"   Track {num:02d}   [{dur}]")
        self.status.showMessage(f"Disc loaded -- {count} tracks")
        self.btn_detect.setEnabled(True)

    def _on_cd_error(self, msg: str):
        self.lbl_cd.setText("x  Detection failed")
        self.lbl_cd.setStyleSheet("color:#cc4444;")
        self._log(f"x  {msg}")
        self.btn_detect.setEnabled(True)

    def _start_rip(self):
        tracks = self.song_table.get_named_tracks()
        if not tracks:
            QMessageBox.warning(self, "No Tracks",
                                "Enter at least one track name before ripping.")
            return
        out_dir = self.out_edit.text().strip()
        if not out_dir:
            QMessageBox.warning(self, "No Output", "Select an output directory.")
            return

        bitrate = self.br_combo.currentData() or "320"
        device  = self.dev_edit.text().strip() or DEFAULT_DEVICE
        artist  = self.artist_edit.text()
        album   = self.album_edit.text()

        self._log(f"\n{'--' * 22}")
        self._log(f"Starting rip: {len(tracks)} track(s)  ->  MP3 @ {bitrate} kbps")
        if artist: self._log(f"Artist: {artist}")
        if album:  self._log(f"Album:  {album}")
        self._log(f"Output: {out_dir}")

        self.prog_bar.setRange(0, len(tracks))
        self.prog_bar.setValue(0)
        self.prog_bar.setFormat("%v / %m  tracks")

        self._worker = RipWorker(tracks, out_dir, bitrate, artist, album, device)
        self._worker.log.connect(self._log)
        self._worker.progress.connect(lambda d, _t: self.prog_bar.setValue(d))
        self._worker.track_active.connect(self.song_table.mark_active)
        self._worker.track_done.connect(self.song_table.mark_done)
        self._worker.finished.connect(self._on_rip_finished)
        self._worker.start()
        self._sync_controls()
        self.status.showMessage("Ripping in progress...")

    def _cancel_rip(self):
        if self._worker:
            self._worker.cancel()
            self._log("Cancellation requested...")

    def _on_rip_finished(self, success: bool, msg: str):
        self._log(f"\n{'OK' if success else 'FAIL'}  {msg}")
        self.status.showMessage(msg)
        self._sync_controls()
        if success:
            QMessageBox.information(self, "Rip Complete", msg)
        else:
            QMessageBox.warning(self, "Rip Stopped", msg)


# =============================================================================
# Entry Point
# =============================================================================

def main():
    # Must be called before QApplication is created
    _set_app_user_model_id()

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyleSheet(QSS)

    # Load icon and set on the application -- this drives the taskbar button,
    # the window title bar, and the Alt+Tab thumbnail
    app_icon: QIcon | None = None
    icon_path = _find_icon()
    if icon_path:
        app_icon = QIcon(str(icon_path))
        app.setWindowIcon(app_icon)

    splash = create_splash(app_icon)
    if splash:
        splash.show()
        for msg in ["Initializing...", "Loading modules...",
                    "Checking dependencies...", "Ready."]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = MainWindow(app_icon)
    win.show()
    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
