# mp3_of_death.spec
#
# PyInstaller spec -- MP3 of Death
# Death's Head Software
#
# pip install pyinstaller pyqt6 mutagen
# Place freaccmd.exe + all its DLLs alongside this file (or in bin\freac\)
# Place icon.ico alongside this file
# Then run: build.bat

import os
from pathlib import Path

block_cipher = None
HERE = Path(".").resolve()

freac_src: Path | None = None
for candidate in [HERE / "freaccmd.exe", HERE / "bin" / "freac" / "freaccmd.exe"]:
    if candidate.exists():
        freac_src = candidate.parent
        break

freac_datas: list[tuple[str, str]] = []
if freac_src is None:
    print("WARNING: freaccmd.exe not found -- it will NOT be bundled.")
else:
    for f in freac_src.rglob("*"):
        if f.is_file():
            rel = f.relative_to(freac_src)
            dest = "bin/freac" if rel.parent == Path(".") else f"bin/freac/{rel.parent}"
            freac_datas.append((str(f), dest))
    print(f"Bundling {len(freac_datas)} file(s) from {freac_src} -> bin/freac/")

added_datas: list[tuple[str, str]] = list(freac_datas)

# Bundle icon.ico as a data file so the running app can load it as a QIcon.
# The exe also gets the icon embedded via the icon= parameter below.
if (HERE / "icon.ico").exists():
    added_datas.append((str(HERE / "icon.ico"), "."))
    print("Bundling icon.ico")
else:
    print("WARNING: icon.ico not found -- window/taskbar icon will be missing.")

if (HERE / "splash.png").exists():
    added_datas.append((str(HERE / "splash.png"), "."))
    print("Bundling splash.png")

a = Analysis(
    ["mp3_of_death.py"],
    pathex=[str(HERE)],
    binaries=[],
    datas=added_datas,
    hiddenimports=[
        "PyQt6.QtCore",
        "PyQt6.QtGui",
        "PyQt6.QtWidgets",
        "mutagen",
        "mutagen.id3",
        "mutagen.mp3",
        "mutagen._util",
        "mutagen.id3._tags",
        "mutagen.id3._frames",
        "mutagen.id3._specs",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "matplotlib", "numpy", "pandas", "scipy",
        "soundfile", "cffi",
        "tkinter", "_tkinter",
        "email", "html", "http", "xml", "xmlrpc",
        "unittest", "test",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="mp3_of_death",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    icon="icon.ico",   # embeds skull into the .exe (Explorer, shortcuts)
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="mp3_of_death",
)
